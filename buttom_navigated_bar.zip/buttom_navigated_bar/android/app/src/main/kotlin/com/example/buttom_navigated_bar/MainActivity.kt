package com.example.buttom_navigated_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
